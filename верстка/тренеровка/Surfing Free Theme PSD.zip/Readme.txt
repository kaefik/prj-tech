Hi there!

Thank you for downloading this PSD freebie, hope it will be useful for you.
This is a free template intended for personal use. The file format is PSD and it uses free fonts and Unsplash images.


# Fonts

Playfair Display: https://fonts.google.com/specimen/Playfair+Display
Poppins: https://fonts.google.com/specimen/Poppins
League Spartan: https://www.theleagueofmoveabletype.com/league-spartan


# Please follow and subscribe (highly appreciated)

Behance: http://be.net/rmayer
Dribbble: https://dribbble.com/mrmayer
Creative Market: https://creativemarket.com/RobertMayer


# License

All PSD files are royalty free to use in both personal and commercial projects.

You are permitted to use this resource in any number of personal and commercial projects for yourself or a client. You may modify the resources according to your requirements and include them into works such as websites, applications, printed materials and others. No attribution or link back to this site is required, however any credit will be much appreciated.

You do not have the rights to resell, sublicense or redistribute (even for free) the files on its own or as a separate attachment from any of your work. If you wish to promote my resources on your site, you must link back to the resource page where users can find the download and not directly to the download file.
If you have any questions about the license, feel free to contact me.